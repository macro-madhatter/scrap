import datetime as dt

import babel.tickers
from adb.adb import lib_analysis, read_symbol
from homer.proc import LB_WINDOWS, enhance_ohlc
import pickle
import pathlib

if __name__ == '__main__':
    failed_read_tickers = []
    failed_write_tickers = []
    failed_write_tickers_dfs = []
    for ticker in babel.tickers.momentum_tickers():
        try:
            df = read_symbol(ticker)
        except Exception as e:
            print(e)
            failed_read_tickers.append(ticker)
            continue

        enhanced_df = enhance_ohlc(df, windows=LB_WINDOWS)
        new_symbol = ticker + "_MOM"
        metadata = dict(run_dt=dt.datetime.today(),
                        windows=LB_WINDOWS)
        try:
            lib_analysis.write(symbol=new_symbol, data=enhanced_df, metadata=metadata)
        except Exception as e:
            print(e)
            failed_write_tickers.append(ticker)
            failed_write_tickers_dfs.append((df, enhanced_df))
            continue

    print(failed_read_tickers)
    print(failed_write_tickers)

    with open(pathlib.Path.cwd().parent / "tyche_assets" / "failed_write_tickers_dfs", 'wb') as fname:
        pickle.dump(failed_write_tickers_dfs, fname)
