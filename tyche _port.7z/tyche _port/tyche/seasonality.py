import pandas as pd
from datetime import date
from adb.adb import read_symbol
from homer.base import BBGTicker
import pprint
import collections
import seaborn as sns
from matplotlib.colors import ListedColormap
from typing import List, Dict, Tuple, Any
from enum import Enum, auto
import calendar
from bbg.acq import interval_change, ohlc, ohlcv
from babel.tickers import uses_ohlc

YYYY = int
MthNum = int


class AutoName(Enum):
    def _generate_next_value_(name, start, count, last_values):
        return name


class SeasonalityPeriodType(AutoName):
    IntraWeek = auto()
    IntraMonth = auto()
    IntraYear = auto()


class SeasonalityRangeManager:
    def __init__(self, start_yr: YYYY, end_yr: YYYY = -1, start_day: int = 1, end_day: int = -1):
        self.start_yr: YYYY = start_yr
        self.end_yr: YYYY = date.today().year if end_yr == -1 else end_yr
        if start_yr > end_yr: raise ValueError("Start Yr: {} must be <= than End Yr: {}".format(start_yr, end_yr))

        self.ranges: Dict[YYYY, Dict[MthNum, Dict[Tuple[date, date], Any]]] = self.create_ranges(start_day, end_day)

    def create_ranges(self, start_day: int = 1, end_day: int = -1):

        def start_end_days(mth: MthNum, yr: YYYY) -> Dict[Tuple[date, date], Any]:
            end_day_for_mth = calendar.monthrange(yr, mth)[1] if end_day == -1 else end_day
            return {
                (date(yr, mth, start_day), date(yr, mth, end_day_for_mth)): None
            }

        if not 1 <= start_day <= 30:
            raise ValueError("Start Day Must be between 1st to 30th")

        if end_day != -1 and (start_day > end_day):
            raise ValueError("Start Day: {} must be <= than End Day: {}".format(start_day, end_day))

        # initialize the ranges
        seasonality_ranges: Dict[YYYY, Dict[MthNum, Dict[Tuple[date, date], Any]]] = {
            yr: {mth: start_end_days(mth, yr) for mth in range(1, 13)}
            for yr in range(self.start_yr, self.end_yr + 1)
        }

        return seasonality_ranges

    def __getitem__(self, yr) -> Dict[MthNum, Dict[Tuple[date, date], Any]]:
        return self.ranges[yr]

    def start_end_dts(self, yr: YYYY, mth_num: MthNum) -> Tuple[date, date]:
        return list(self.ranges[yr][mth_num].keys())[0]

    @property
    def nested(self):
        return [list(d.values()) for d in list(self.ranges.values())]

    @property
    def flattened(self):
        return [item for sublist in self.nested for item in sublist]

    @property
    def first_date(self):
        return self.flattened[0]

    @property
    def last_date(self):
        return self.flattened[-1]

    @property
    def years(self) -> List[YYYY]:
        return list(self.ranges.keys())

    @staticmethod
    def from_lis_date_tuples(l: List[Tuple[date, date]]) -> Dict[YYYY, Dict[MthNum, Dict[Tuple[date, date], Any]]]:
        years = [tup[1].year for tup in l]
        months = [tup[1].month for tup in l]

        return {
            yr: {mth: {v: None} for mth, v in zip(months, l)}
            for yr in years
        }


class SeasonalityStudy:
    def __init__(self, ticker: BBGTicker, start_yr: int, end_yr: int = -1, start_day: int = 1, end_day: int = -1):
        self.ticker: BBGTicker = ticker
        self.range_manager: SeasonalityRangeManager = SeasonalityRangeManager(start_yr, end_yr, start_day, end_day)
        self._df: pd.DataFrame = pd.DataFrame()

    def _calculate_range_metric(self, fn, *args, **kwargs):
        for yr in self.range_manager.years:
            for mth_num in self.range_manager[yr].keys():
                st, end = self.range_manager.start_end_dts(yr, mth_num)
                val = fn(st=st, end=end, *args, **kwargs)
                self.range_manager[yr][mth_num][(st, end)] = val

    def _calculate_chg_bbg(self, as_pct: bool = True):
        self._calculate_range_metric(interval_change, ticker=self.ticker, as_pct=as_pct)

    def _calculate_custom(self, ts_fn, use_db=True, *args, **kwargs):
        """
        Ts_fn should process an ohlc/ohlcv pd.DataFrame and return a scalar value
        """

        loader_fn = read_symbol if use_db else ohlc if uses_ohlc(self.ticker) else ohlcv

        def wrapper_fn(ticker, ts_fn, loader_fn, st, end, *args, **kwargs):
            df: pd.DataFrame = loader_fn(ticker, st, end)
            return ts_fn(df, *args, **kwargs)

        self._calculate_range_metric(fn=wrapper_fn,
                                     ticker=self.ticker,
                                     ts_fn=ts_fn,
                                     loader_fn=loader_fn,
                                     *args,
                                     **kwargs
                                     )

    def as_df(self, recalc: bool = True):
        if self._df.empty or recalc:
            series_dict = dict()
            series_dict['Year'] = pd.Series(list(d.keys())[0][1].year for d in self.range_manager.flattened)
            series_dict['Month'] = pd.Series(list(d.keys())[0][1].month for d in self.range_manager.flattened)
            series_dict['RangeTuple'] = pd.Series(list(d.keys())[0] for d in self.range_manager.flattened)
            series_dict['Value'] = pd.Series(list(d.values())[0] for d in self.range_manager.flattened)
            self._df = pd.DataFrame.from_dict(series_dict)

        return self._df


class TickerStudy:
    def __init__(self, ticker: BBGTicker, start_yr: int, end_yr: int = -1, use_net: bool = False):
        self.ticker: BBGTicker = ticker

        self.start_yr: int = start_yr
        self.end_yr: int = date.today().year if end_yr == -1 else end_yr

        if self.start_yr > self.end_yr:
            raise ValueError("Start Yr: {} must be <= than End Yr: {}".format(start_yr, end_yr))

        self.st: date = date(start_yr, 1, 1)
        self.end: date = date(end_yr, 12, 31)

        self.df: pd.DataFrame = read_symbol(ticker, self.st, self.end)

        self.px_open: pd.Series = self.df['open'].resample('BMS').first()
        self.px_high: pd.Series = self.df['high'].resample('BMS').max()
        self.px_low: pd.Series = self.df['low'].resample('BMS').min()
        self.px_close: pd.Series = self.df['close'].resample('BMS').last()

        self.net_diff: pd.Series = self.px_close - self.px_open
        # noinspection PyTypeChecker
        self.pct_diff: pd.Series = (self.net_diff * 100) / self.px_open

        self.monthly_chg: pd.DataFrame = pd.DataFrame()
        self.monthly_chg['Diff'] = self.net_diff if use_net else self.pct_diff
        self.monthly_chg['Mth'] = self.monthly_chg['Diff'].index.month_name()

        self.fin = self.monthly_chg.groupby(['Mth']).mean()
        self.fin.columns = ['Mean']

        self.fin['NumAboveZero'] = self.monthly_chg.groupby(['Mth']).apply(lambda x: x[x > 0].count())
        self.fin['RatioAboveZero'] = self.monthly_chg.groupby(['Mth']).apply(lambda x: x[x > 0].count() / len(x))
        self.fin['Max'] = self.monthly_chg.groupby(['Mth']).max()
        self.fin['Min'] = self.monthly_chg.groupby(['Mth']).min()
        self.fin['Median'] = self.monthly_chg.groupby(['Mth']).median()
        self.fin['Std'] = self.monthly_chg.groupby(['Mth']).std()

        self._details = collections.OrderedDict()

        self._details['start_dt'] = self.df.index[0].date()
        self._details['end_dt'] = self.df.index[-1].date()

        self._details['num_yrs'] = (self._details['end_dt'].year - self._details['start_dt'].year) + 1
        self._details['num_mths'] = len(self.px_close.index)

        pprint.pprint("Details")
        pprint.pprint(self._details)

    @property
    def final_df(self) -> pd.DataFrame:
        return self.fin

    @property
    def table(self) -> pd.DataFrame:
        tbl: pd.DataFrame = self.monthly_chg.copy(deep=True)
        tbl['Yr'] = tbl['Diff'].index.year
        tbl = tbl.pivot('Yr', 'Mth', 'Diff')
        tbl = tbl.round({x: 1 for x in range(1, 13)})
        return tbl

    @property
    def heat_map(self):
        c_map = ListedColormap(['brown', 'seagreen'])
        return sns.heatmap(self.table, annot=True, cmap=c_map, cbar=True)


class BasketStudy:
    def __init__(self, tickers: List[BBGTicker], start_yr: int, end_yr: int, use_net: bool = False):
        self._studies: Dict[BBGTicker, TickerStudy] = {t: TickerStudy(t, start_yr, end_yr, use_net) for t in
                                                       tickers}

        def study(self, ticker: BBGTicker) -> TickerStudy:
            return self._studies[ticker]

        @property
        def all_studies(self) -> Dict[BBGTicker, TickerStudy]:
            return self._studies
