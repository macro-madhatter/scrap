import datetime as dt
import logging
import pickle
import pprint
from typing import List, Sequence
import pathlib
import babel.tickers
import homer.math_utils as mu
import pandas as pd
from adb.adb import read_symbol, read_symbol_analysis
from homer.base import Signal, BBGTicker
from homer.proc import enhance_ohlc

# Logging
logger = logging.getLogger('Momentum')
logger.setLevel(logging.DEBUG)

# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(formatter)
logger.addHandler(ch)

# Moving Average Definitions
MAvgWindows = Sequence[int]

WeekWindows: MAvgWindows = (3, 5, 10)
MonthWindows: MAvgWindows = (5, 10, 20)
QuarterWindows: MAvgWindows = (20, 50, 75)
HalfYrWindows: MAvgWindows = (75, 100, 150)
YearWindows: MAvgWindows = (100, 150, 200)
MultiYearWindows: MAvgWindows = (200, 350, 500)

DEFAULT_THRESH_ZSCORE: float = 1.25


def _mom_test(df: pd.DataFrame, ticker: BBGTicker, mom_fn, windows, *mom_fn_args, **mom_fn_kwargs):
    return Signal(ticker, mom_fn(df, windows, *mom_fn_args, **mom_fn_kwargs))


def over_under_mavgs(df: pd.DataFrame, averages: MAvgWindows) -> int:
    last_row, last_px = mu.last_metrics(df)

    print(last_row)

    ma_keys: Sequence[str] = ['{}DMA'.format(ma) for ma in averages]
    ma_vals: Sequence[int] = [last_row[k] for k in ma_keys]

    logger.info("LastPx: {}".format(last_px))
    logger.info("Moving Averages: {}".format({k: last_row[k] for k in ma_keys}))

    return mu.all_above_below(val=last_px, lis=ma_vals)


def _zscore(df: pd.DataFrame, averages: MAvgWindows, zscore_colname: str, thresh: float = 1) -> int:
    last_row, _ = mu.last_metrics(df)

    zscore_keys: Sequence[str] = [zscore_colname + '_{}d'.format(ma) for ma in averages]
    zscore_vals: Sequence[int] = [last_row[k] for k in zscore_keys]

    return mu.all_above_below(val=thresh, lis=zscore_vals)


def pct_zscore(df: pd.DataFrame, averages: MAvgWindows, thresh: float = DEFAULT_THRESH_ZSCORE) -> int:
    return _zscore(df, averages, zscore_colname='close_pct_zscore', thresh=thresh)


def px_zscore(df: pd.DataFrame, averages: MAvgWindows, thresh: float = DEFAULT_THRESH_ZSCORE) -> int:
    return _zscore(df, averages, zscore_colname='close_px_zscore', thresh=thresh)


def net_zscore(df: pd.DataFrame, averages: MAvgWindows, thresh: float = DEFAULT_THRESH_ZSCORE) -> int:
    return _zscore(df, averages, zscore_colname='close_net_zscore', thresh=thresh)


def autocorr(df: pd.DataFrame, averages: MAvgWindows, thresh: float = 0.65) -> int:
    if 1 in averages:
        raise ValueError("Mininmum Window size >=3")

    last_row, _ = mu.last_metrics(df)

    autocorr_keys: Sequence[str] = ['autocorr_{}d'.format(ma) for ma in averages]
    autocorr_vals: Sequence[int] = [last_row[k] for k in autocorr_keys]

    return mu.all_above_below(val=thresh, lis=autocorr_vals)


def compound_momentum(df: pd.DataFrame, lis_mom_fns, lis_averages: List[MAvgWindows], use_pct=True) -> int:
    return mu.same_sign([fn(df, window, use_pct=use_pct) for fn, window in zip(lis_mom_fns, lis_averages)])


def test():
    df = enhance_ohlc(read_symbol('USDJPY CURNCY', dt.date(2010, 1, 1), dt.date.today()))
    _mom_test(df, 'USDJPY CURNCY', over_under_mavgs, YearWindows)


def runner(recompute_metrics: bool = False, st=dt.datetime(2015, 1, 1), end=dt.datetime.today()):
    sigs: List[Signal] = []
    failed_tickers: List[BBGTicker] = []

    for ticker in babel.tickers.momentum_tickers():
        if recompute_metrics:
            df = enhance_ohlc(read_symbol(ticker, st, end))
        else:
            # Load from Analysis Library
            df = read_symbol_analysis(ticker + "_MOM", st, end)

        logger.info("Parsing Ticker: {}".format(ticker))
        try:
            curr_sig = _mom_test(df, ticker, over_under_mavgs, YearWindows)
            sigs.append(curr_sig)
        except Exception as e:
            logger.error(e)
            failed_tickers.append(ticker)

    # Parse the Signals
    filtered_sigs = filter(lambda s: s.direction != 0, sigs)

    pprint.pprint({sig.ticker: sig.direction} for sig in filtered_sigs)

    pprint.pprint("Failed Tickers")
    pprint.pprint(failed_tickers)

    sig_fname: str = 'mom_sigs_{}_.pkl'.format(dt.date.today())
    failed_fname: str = 'failed_tickers_{}_.pkl'.format(dt.date.today())

    with open(pathlib.Path.cwd().parent / "tyche_assets" / failed_fname, 'wb') as f:
        pickle.dump(failed_tickers, f)

    with open(pathlib.Path.cwd().parent / "tyche_assets" / sig_fname, 'wb') as f:
        pickle.dump(sigs, f)


if __name__ == '__main__':
    runner()
