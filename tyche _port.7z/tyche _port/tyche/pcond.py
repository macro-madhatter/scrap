import datetime as dt
import pandas as pd
import numpy as np
from functools import wraps
from homer.base import BBGTicker
import homer.math_utils as mu
import homer.proc as proc
from adb.adb import read_symbol
import logging
from typing import List, Dict
from babel.tickers import is_ndf, get_base_ticker

# Logging
logger = logging.getLogger('PCond')
logger.setLevel(logging.DEBUG)

# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(formatter)
logger.addHandler(ch)


def check_sigfn(sigfn):
    @wraps(sigfn)
    def wrapper(df_dict: Dict[BBGTicker, pd.DataFrame], *args, **kwargs):
        logger.info('Testing SigFn: {}'.format(sigfn.__name__))
        df = sigfn(df_dict, *args, **kwargs)
        if 'sig' not in list(df):
            raise ValueError("Expected sigfn {} to create signal column named: {}".format(sigfn.__name__, 'sig'))
        else:
            return df

    return wrapper


@check_sigfn
def sample_sigfn(ticker: BBGTicker, df_dict: Dict[BBGTicker, pd.DataFrame]) -> pd.DataFrame:
    """

    Args:
        df_dict Dict[BBGTicker, pd.DataFrame]: Enhanced OHLC Dataframes of requested tickers

    Returns:
        pd.DataFrame: Underlying dataframe with 'sig' column

        Applies user-defined logic to parse underlying + other relevant instrument dataframes
        Creates 'sig' column comprised of [0,1,-1] values

    Raises:
        ValueError: If column 'sig' is not contained in returned dataframe
    """

    underlying: BBGTicker = ticker

    base_ticker = get_base_ticker(underlying) if is_ndf(underlying) else underlying

    underlying_rr: BBGTicker = base_ticker.split(" ")[0] + "25R1M " + "CURNCY"

    df_underlying: pd.DataFrame = df_dict[underlying]
    original_underlying_cnames: List[str] = list(df_underlying)

    # Create aligned dataframe with renamed columns
    df_aligned, missing_dates = mu.align_timeseries_dfs(df_dict)

    # We sell  on the days that implied vols jump - assuming jumps in 1M 25D Riskies correspond to risk events
    df_aligned['sig'] = 0
    # df_aligned['sig'] = np.where(df_aligned['close_net_chg_1d_{}'.format(underlying_rr)] < -0.45, -1, df_aligned['sig'])
    df_aligned['sig'] = np.where(df_aligned['close_net_chg_1d_{}'.format(underlying_rr)] > 0.30, 1, df_aligned['sig'])

    # Create subset of aligned containing only underlying data
    updated_underlying_cnames: List[str] = [cname + "_{}".format(underlying) for cname in
                                            original_underlying_cnames] + ['sig']

    sig_df: pd.DataFrame = df_aligned[updated_underlying_cnames]
    # Restore the column names
    sig_df.columns = original_underlying_cnames + ['sig']

    return sig_df


@check_sigfn
def gap_moves_sigfn(ticker: BBGTicker, df_dict: Dict[BBGTicker, pd.DataFrame], gap_pct: float) -> pd.DataFrame:
    """
    This sigfn is based on supposed conditional autocorrelation of an illiquid currency

    Args:
        ticker BBGTicker
        df_dict Dict[BBGTicker, pd.DataFrame]: Enhanced OHLC Dataframes of requested tickers
        gap_pct float: The over/under cut-off for the gap

    Returns:
        pd.DataFrame: Underlying dataframe with 'sig' column

        Applies user-defined logic to parse underlying + other relevant instrument dataframes
        Creates 'sig' column comprised of [0,1,-1] values

    Raises:
        ValueError: If column 'sig' is not contained in returned dataframe
    """

    underlying: BBGTicker = ticker

    # Unlike in sample_sigfn we only rely on the underlying, so there is no need to align with other instruments
    df_underlying: pd.DataFrame = df_dict[underlying]

    # We buy/sell USDIDR on the next day if for the previous day spot has moved by more than 0.75%
    df_underlying['sig'] = 0
    df_underlying['sig'] = np.where(df_underlying['close_pct_chg_1d'] >= gap_pct, 1, df_underlying['sig'])
    # df_underlying['sig'] = np.where(df_underlying['close_pct_chg_1d'] <= -gap_pct, -1, df_underlying['sig'])

    return df_underlying


if __name__ == '__main__':
    start_dt = dt.date(2015, 1, 1)
    wsizes = [1, 5, 10]
    df = proc.enhance_ohlc(read_symbol('USDJPY CURNCY', start_dt, dt.date.today()), windows=wsizes)
    df_atm_vol = proc.enhance_ohlc(read_symbol('USDJPYV1M CURNCY', start_dt, dt.date.today()), windows=wsizes)
    df_25d_rr = proc.enhance_ohlc(read_symbol('USDJPY25R1M CURNCY', start_dt, dt.date.today()), windows=wsizes)

    sig_df = sample_sigfn({'USDJPY CURNCY': df, 'USDJPYV1M CURNCY': df_atm_vol, 'USDJPY25R1M CURNCY': df_25d_rr})

    # print(sig_df.head())
    print(len(sig_df))
    from signal_utils import SignalEvaluationManager

    sim: SignalEvaluationManager = SignalEvaluationManager(sig_df, holding_periods=[1, 3, 5])
    print(sim.compute_for_holding_period(3))
