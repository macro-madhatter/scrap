import pandas as pd
import datetime as dt
from adb.adb import read_symbol
from homer.base import BBGTicker
import pprint
import collections
import seaborn as sns
from matplotlib.colors import ListedColormap
from typing import List, Dict

class TickerStudy:
    def __init__(self, ticker: BBGTicker, start_yr: int, end_yr: int, use_net: bool = False):
        self.ticker: BBGTicker = ticker
        self.st: dt.date = dt.date(start_yr, 1, 1)
        self.end: dt.date = dt.date(end_yr, 12, 31)

        self.ts: pd.DataFrame = read_symbol(ticker, self.st, self.end)
        self.px_open: pd.Series = self.ts['open'].resample('BMS').first()
        self.px_high: pd.Series = self.ts['high'].resample('BMS').max()
        self.px_low: pd.Series = self.ts['low'].resample('BMS').min()
        self.px_close: pd.Series = self.ts['close'].resample('BMS').last()

        self.net_diff: pd.Series = self.px_close - self.px_open
        # noinspection PyTypeChecker
        self.pct_diff: pd.Series = (self.net_diff * 100) / self.px_open

        self.mths = self.pct_diff.index.month_name()
        self.seag: pd.DataFrame = pd.DataFrame()

        self.seag['Diff'] = self.net_diff if use_net else self.pct_diff

        self.seag['Mth'] = self.seag['Diff'].index.month_name()

        self.fin = self.seag.groupby(['Mth']).mean()
        self.fin.columns = ['Mean']

        self.fin['NumAboveZero'] = self.seag.groupby(['Mth']).apply(lambda x: x[x > 0].count())
        self.fin['RatioAboveZero'] = self.seag.groupby(['Mth']).apply(lambda x: x[x > 0].count() / len(x))
        self.fin['Max'] = self.seag.groupby(['Mth']).max()
        self.fin['Min'] = self.seag.groupby(['Mth']).min()
        self.fin['Median'] = self.seag.groupby(['Mth']).median()
        self.fin['Std'] = self.seag.groupby(['Mth']).std()

        self._details = collections.OrderedDict()

        self._details['start_dt'] = self.ts.index[0].date()
        self._details['end_dt'] = self.ts.index[-1].date()

        self._details['num_yrs'] = (self._details['end_dt'].year - self._details['start_dt'].year) + 1
        self._details['num_mths'] = len(self.px_close.index)

        pprint.pprint("Details")
        pprint.pprint(self._details)

    @property
    def df(self) -> pd.DataFrame:
        return self.fin
    
    @property
    def table(self) -> pd.DataFrame:
        tbl: pd.DataFrame = self.seag.pivot('Yr','MthNum','Diff') 
        tbl = tbl.round({x:1 for x in range(1,13)})
        return tbl
    
    @property
    def heatmap:
        cmap=ListedColormap(['brown', 'seagreen'])
        return sns.heatmap(self.tbl, annot=True,cmap=cmap,cbar=False)
        
class BasketStudy:
    def __init__(self, tickers: List[BBGTicker], start_yr: int, end_yr: int, use_net: bool = False):
        self._studies: Dict[BBGTicker, TickerStudy] ={t:TickerStudy(t,start_yr,end_yr,use_net:)}
        
    
    def study(self, ticker:BBGTicker) -> TickerStudy:
        return self._studies[ticker]
    
    @property
    def all_studies(self) -> Dict[BBGTicker, TickerStudy]:
        return self._studies