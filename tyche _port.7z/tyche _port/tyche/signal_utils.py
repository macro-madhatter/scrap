import pandas as pd
import datetime as dt
from adb.adb import read_symbol
from homer.base import BBGTicker, Signal
import homer.math_utils as mu
from typing import Sequence, List, Tuple, Set, Dict, Any
from collections import Counter
import babel.ccy
import babel.tickers
from dataclasses import dataclass
from enum import Enum
from astropy.table import QTable

DEFAULT_HOLDING_PERIODS: Sequence[int] = (1, 3, 5, 10, 20, 60, 120, 250)


class EntryPt(Enum):
    CurrDayClose = 0
    NextDayOpen = 1


class SignalHoldingPeriodResult:
    """
    Initialized by passing the chunk
    First row of the df chunk is the day on the CLOSE of which the signal is triggered
    For example, we monitor for days where close-open % change >= 1%
    Assume 27May2020 is a Monday (tradeable day) and 28May2020 is a Tuesday (tradable day)
    If 27May2020 is the day for which 27May2020_close - 27May2020_open difference is >= 1%
    Then 27May2020 must be the FIRST row of the chunk, and 28May2020 the second row of the chunk
    EntryPoint will determine whether the entry will be on the close of 27May2020 (CurrDayClose)
    Or rather, will the trade be entered on OPEN of 28May2020 (NextDayOpen)
    """

    def __init__(self, chunk: pd.DataFrame, entry_point: EntryPt = EntryPt.NextDayOpen, dir: int = None):
        self.chunk: pd.DataFrame = chunk

        self.dir = dir if dir else chunk.iloc[0]['sig']
        if self.dir == 0:
            raise ValueError("Expected Either -1 or +1 for sig, but received: {}".format(self.dir))

        self.entry = self.chunk.iloc[0]['close'] if entry_point == EntryPt.NextDayOpen else self.chunk.iloc[1]['open']
        self.entry_dt: dt.date = self.chunk.iloc[1].name.date()

        self.exit = self.chunk.iloc[-1]['close']
        self.exit_dt: dt.date = self.chunk.iloc[-1].name.date()

        # The days the signal is generated
        # If sig==1 for 27May20, then regardless if the trade is entered at 27th Close or 28thOpen
        # The trade is active from 28th to whenever the holding period ends
        self.trade_active_df: pd.DataFrame = self.chunk.iloc[1:]

        self.pnl = (self.exit - self.entry) * self.dir
        self.running_pnl: pd.Series = self.trade_active_df['close'] - self.entry
        self.running_pnl = self.running_pnl * self.dir

        self.running_high: pd.Series = self.trade_active_df['high'].cummax()
        self.running_low: pd.Series = self.trade_active_df['low'].cummin()

        self.win = 1 if self.pnl > 0 else -1
        self.days_held: int = (self.exit_dt - self.entry_dt).days
        self.avg_pnl_day: float = self.pnl / self.days_held

        self.high = max(chunk['high'])
        self.low = min(chunk['low'])

        if self.dir == 1:
            self.max_gain = self.high - self.entry
            self.running_max_gain: pd.Series = self.running_high - self.entry
            self.max_gain_pct = round((self.high - self.entry) * 100 / self.entry, 2)

            self.max_loss = self.low - self.entry
            self.running_max_loss = self.running_low - self.entry
            self.max_loss_pct = round((self.low - self.entry) * 100 / self.entry, 2)

        elif self.dir == -1:
            self.max_gain = self.entry - self.low
            self.running_max_gain = (self.running_low * -1) + self.entry
            self.max_gain_pct = round((self.entry - self.low) * 100 / self.entry, 2)

            self.max_loss = (self.high * -1) + self.entry
            self.max_loss_pct = round((self.entry - self.high) * 100 / self.entry, 2)

        # Set conservative max_loss calculation by assuming max loss is min(-10% of max gain, max_loss)
        self.max_loss = min(-0.1 * self.max_gain, self.max_loss)

        # abs(max_gain) / abs(max_loss)
        # If > 1 ==> then you gained 1.x for every 1 risked (gr8)
        # If < 1 ==> then you gained 0.x for every 1 risked (bad)
        self.max_gain_loss_ratio = round(self.max_gain / abs(self.max_loss), 2)

    def as_dict(self) -> Dict[str, Any]:
        return {
            'entry_dt': self.entry_dt,
            'exit_dt': self.exit_dt,
            'dir': self.dir,
            'entry': self.entry,
            'exit': self.exit,
            'win': self.win,
            'pnl': self.pnl,
            'max_gain': self.max_gain,
            'max_loss': self.max_loss,
            'max_gain_loss_ratio': self.max_gain_loss_ratio,
        }

    def as_df(self) -> pd.DataFrame:
        return pd.DataFrame.from_dict(self.as_dict())

    def as_qtable(self) -> QTable:
        return QTable(list(self.as_dict().values()), names=list(self.as_dict().keys()))


class SignalEvaluationManager:
    """
    Runs the signals across different look-ahead periods and aggregates performance details
    """

    def __init__(self, sig_df: pd.DataFrame, holding_periods: Set[int] = DEFAULT_HOLDING_PERIODS):
        """

        Args:
            sig_df (pd.DataFrame): DataFrame of the underlying with atleast OHLC and 'sig' columns
            holding_periods (Set[Int]): Days holding the underlying
        """
        self.sig_df: pd.DataFrame = sig_df
        self.holding_periods = holding_periods

        # Get the indices for non-zero values of signal
        nonzero_sig_idx: pd.Index = sig_df.index[(sig_df['sig'] == 1) | (sig_df['sig'] == -1)]
        sig_indices: List[int] = [sig_df.index.get_loc(idx) for idx in nonzero_sig_idx]

        # Chunk the sig_df into list of smaller dataframes corresponding to holding period
        self.chunks_per_holding_period: Dict[int:List[pd.DataFrame]] = {
            hp: [sig_df.iloc[i:(i + hp + 1)] for i in sig_indices] for hp in holding_periods
        }

    def holding_period_results(self, hp: int, logger=None) -> pd.DataFrame:
        results = [SignalHoldingPeriodResult(chunk) for chunk in self.chunks_per_holding_period[hp]]
        results_as_dicts: List[Dict[str, Any]] = [r.as_dict() for r in results]
        results_as_df: pd.DataFrame = pd.DataFrame(results_as_dicts)

        del results_as_dicts

        relevant_colnames = ['pnl', 'win', 'max_gain_loss_ratio', ]

        if logger:
            for cname in relevant_colnames:
                logger.info(results_as_df[cname].describe())
        else:
            for cname in relevant_colnames:
                heading = "{} Results:".format(cname)
                print(heading)
                print("".join(["="] * len(heading)))
                print(results_as_df[cname].describe())
                print("".join(["="] * len(heading)))
                print("\n")

        return results_as_df

#     def split_cross_signal(s: Signal, base: str = "USD") -> Tuple[Signal, Signal]:
#         """
#         Split the signal of cross FX trades into two base trades
#         Ex. AUDINR: +1 == AUDUSD +1, USDINR+1
#         """
#         ccy1, ccy2 = babel.ccy.get_ccys(s.ticker)
#         split_1, split_2 = babel.ccy.bases_from_cross(s.ticker, base)
#
#         sig1 = Signal(split_1, s.direction if ccy1 == split_1[:3] else -s.direction)
#         sig2 = Signal(split_2, -s.direction if ccy2 == split_2[:3] else s.direction)
#
#         return sig1, sig2
#
#     def consolidate_signals(signals: List[Signal], base: str = "USD") -> Tuple[Counter, Counter]:
#         """
#         Consolidate fxoutright and other instrument symbols into counters
#         This includes splitting crosses
#         """
#
#         c_outright = Counter()
#         c_other = Counter()
#
#         for s in signals:
#             if babel.tickers.is_outright(s.ticker):
#                 if babel.ccy.is_cross(s.ticker, base):
#                     split_signals = split_cross_signal(s, base)
#                     for split_s in split_signals:
#                         c_outright[split_s.ticker] += split_s.direction
#                 else:
#                     c_outright[s.ticker] += s.direction
#             else:
#                 c_other[s.ticker] += s.direction
#
#         return c_outright, c_other
#
#     def diff_signals(curr_sig: Counter, prev_sig: Counter) -> Counter:
#         diff: Counter = Counter(curr_sig.elements())
#         diff.subtract(prev_sig)
#         return diff
#
#     def consensus_signals(signals: List[Signal], split_crosses=True) -> List[Signal]:
#         """Filter list of Signals and return the tickers for which all signals have same direction"""
#
#         final_signals = []
#
#         if split_crosses:
#             for s in signals:
#                 if babel.ccy.is_cross(s.ticker):
#                     s1, s2 = split_cross_signal(s)
#                     final_signals.extend([s1, s2])
#                 else:
#                     final_signals.append(s)
#         else:
#             final_signals = signals
#
#         print([{s.ticker: s.direction} for s in final_signals])
#         tickers: Set[BBGTicker] = set([s.ticker for s in final_signals])
#         consensus = {}
#
#         for t in tickers:
#             lis_directions = [s.direction for s in final_signals if s.ticker == t]
#             if mu.all_above_below(0, lis_directions):
#                 consensus[t] = lis_directions[0]
#
#         return [Signal(t, sigdir) for t, sigdir in consensus.items()]
#
#     def test_consensus_signals():
#         sigs = [
#             Signal("AUDUSD CURNCY", 1),
#             Signal("AUDINR CURNCY", 1),
#             Signal("USDINR CURNCY", -1),
#             Signal("USDJPY CURNCY", 1),
#             Signal("USDJPY CURNCY", 1)
#         ]
#
#         consensus = consensus_signals(sigs, split_crosses=True)
#         consensus_dict = {s.ticker: s.direction for s in consensus}
#
#         print(consensus_dict)
#
#         assert consensus_dict == {
#             "AUDUSD CURNCY": 1,
#             "USDJPY CURNCY": 1,
#         }
#
#
# if __name__ == '__main__':
#     test_consensus_signals()
