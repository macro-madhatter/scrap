import logging
import pathlib
import pprint
from typing import Any
from typing import List, Tuple, Dict
from collections import Counter

import pytest

from smtdata.models import *

# create logger
logger = logging.getLogger('Reference')
logger.setLevel(logging.DEBUG)

# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# create file handler which logs even debug messages
# fh = logging.FileHandler('HistoricalDataValidation_{}.log'.format(dt.date.today()))
# fh.setLevel(logging.DEBUG)
# fh.setFormatter(formatter)
# logger.addHandler(fh)

# create console handler with a higher log level

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(formatter)
logger.addHandler(ch)



TICKERS_FNAME: str = "BBGTickerList.csv"

ORDERED_CCYS: List[str] = [
    'EUR',
    'GBP',
    'AUD',
    'NZD',
    'USD',
    'CHF',
    'CAD',
    'SGD',
    'HKD',
    'CNH',
    'CNY',
    'TWD',
    'THB',
    'PHP',
    'INR',
    'JPY',
    'KRW',
    'IDR',
]


def ccy_rank(ccy: str) -> int:
    return ORDERED_CCYS.index(ccy)


def compare_ccys(ccy1, ccy2):
    return ccy_rank(ccy1) < ccy_rank(ccy2)


def convert_to_base(ccy: str, base: str = "USD") -> str:
    ccypair = base + ccy if compare_ccys(base, ccy) else ccy + base
    return ccypair + " CURNCY"


def get_ccys(cross: str) -> Tuple[str, str]:
    return cross[:3], cross[3:6]


def is_cross(ccypair: str, base: str = "USD"):
    try:
        ccy1, ccy2 = get_ccys(ccypair)
    except Exception:
        return False

    try:
        if not all([ccy in ORDERED_CCYS for ccy in [ccy1, ccy2]]):
            return False
        else:
            return ccy1 != base and ccy2 != base
    except Exception:
        return False


def split_cross(cross: BBGTicker, base='USD') -> Tuple[BBGTicker, BBGTicker]:
    """
    :param base: base ccy to split the cross against
    :param cross: Cross ex. AUDINR CURNCY
    :return: AUDUSD CURNCY, USDINR CURNCY
    """
    cross = cross[:6]  # AUDINR CURNCY --> AUDINR
    ccy1, ccy2 = get_ccys(cross)

    if ccy1 == ccy2:
        raise ValueError("CCY1:{} and CCY2:{} cannot be the same".format(ccy1, ccy2))

    if base in [ccy1, ccy2]:
        raise ValueError("Base currency: {} already present in cross: {}".format(base, cross))

    return convert_to_base(ccy1, base), convert_to_base(ccy2, base)


def split_cross_signal(cross: BBGTicker, signal: int, base: str = "USD") -> Dict[BBGTicker, int]:
    ccy1, ccy2 = get_ccys(cross)
    split_1, split_2 = split_cross(cross, base)

    return {
        split_1: signal if ccy1 == split_1[:3] else -signal,
        split_2: -signal if ccy2 == split_2[:3] else signal
    }


JPY_BASKET: Basket = [
    'USDJPY CURNCY',
    'AUDJPY CURNCY',
    'CADJPY CURNCY',
    'NZDJPY CURNCY',
    'EURJPY CURNCY',
    'CHFJPY CURNCY',
    'SGDJPY CURNCY',
    'CNHJPY CURNCY',
    'JPYKRW CURNCY',
    'GBPJPY CURNCY'
]

EUR_BASKET: Basket = [
    'EURUSD CURNCY',
    'EURAUD CURNCY',
    'EURCAD CURNCY',
    'EURNZD CURNCY',
    'EURJPY CURNCY',
    'EURCHF CURNCY',
    'EURSGD CURNCY',
    'EURCNH CURNCY',
    'EURKRW CURNCY',
    'EURGBP CURNCY'
]

CAD_BASKET: Basket = [
    'USDCAD CURNCY',
    'AUDCAD CURNCY',
    'EURCAD CURNCY',
    'NZDCAD CURNCY',
    'CADJPY CURNCY',
    'CADCHF CURNCY',
    'CADSGD CURNCY',
    'CADCNH CURNCY',
    'CADKRW CURNCY',
    'GBPCAD CURNCY'
]

USD_BASKET: Basket = [
    'USDJPY CURNCY',
    'AUDUSD CURNCY',
    'NZDUSD CURNCY',
    'EURUSD CURNCY',
    'USDCHF CURNCY',
    'USDSGD CURNCY',
    'USDCNH CURNCY',
    'USDKRW CURNCY',
    'USDGBP CURNCY'
]

SGD_BASKET: Basket = [
    'USDSGD CURNCY',
    'AUDSGD CURNCY',
    'EURSGD CURNCY',
    'GBPSGD CURNCY',
    'SGDCNH CURNCY',
    'SGDIDR CURNCY',
    'SGDINR CURNCY',
    'SGDJPY CURNCY',
    'SGDKRW CURNCY',
    'SGDPHP CURNCY',
    'SGDTHB CURNCY',
    'SGDTWD CURNCY'
]


def _read_ticker_universe() -> pd.DataFrame:
    df: pd.DataFrame = pd.read_csv(ASSETS / TICKERS_FNAME)
    print('Trying to coerce IS_MANDATED col vals to  Bool')
    try:
        df['IS_MANDATED'].map({'TRUE': True, 'FALSE': False})
    except KeyError:
        pass
    print('Assuming IS_MANDATED col vals are read as Bool by default')
    return df




def duplicate_tickers() -> Counter:
    c_1, c_2 = Counter(), Counter()

    for t in _tickers():
        c_1[t] += 1

    for t in _tickers():
        if c_1[t] > 1:
            c_2[t] = c_1[t]

    return c_2


def test_split_cross():
    assert split_cross("AUDINR CURNCY") == ("AUDUSD CURNCY", "USDINR CURNCY")
    assert split_cross("AUDINR CURNCY", "EUR") == ("EURAUD CURNCY", "EURINR CURNCY")

    with pytest.raises(ValueError):
        split_cross("AUDAUD CURNCY", "EUR")

    with pytest.raises(ValueError):
        split_cross("AUDUSD CURNCY")

    assert split_cross("AUDUSD CURNCY", "EUR") == ("EURAUD CURNCY", "EURUSD CURNCY")


def test_split_cross_signal():
    assert split_cross_signal("AUDINR CURNCY", -1) == {
        "AUDUSD CURNCY": -1,
        "USDINR CURNCY": -1,
    }

    assert split_cross_signal("AUDINR CURNCY", -1, "EUR") == {
        "EURAUD CURNCY": 1,
        "EURINR CURNCY": -1,
    }

    assert split_cross_signal("EURCAD CURNCY", 1, "USD") == {
        "EURUSD CURNCY": 1,
        "USDCAD CURNCY": 1,
    }


def test_is_cross():
    assert not is_cross("EURUSD")
    assert is_cross("EURCAD")
    assert not is_cross("EURCAD", base="EUR")


if __name__ == '__main__':
    pprint.pprint(etf_tickers())


