import logging
import pprint
from pymongo import MongoClient
from homer.base import BBGTicker

CLIENT = MongoClient()
print(CLIENT)
TICKERVERSE = CLIENT.tickerverse.tickerverse
print(TICKERVERSE)

# create logger
logger = logging.getLogger(__name__)

logger.setLevel(logging.INFO)

# create console handler and set level to debug
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)

# create formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

# add formatter to ch
ch.setFormatter(formatter)

# add ch to logger
logger.addHandler(ch)


def _find(**kwargs):
    logger.info(pprint.pformat(kwargs))
    return TICKERVERSE.find(kwargs)


def _find_one(**kwargs):
    logger.info(pprint.pformat(kwargs))
    return TICKERVERSE.find_one(kwargs)


def refdata(ticker: BBGTicker):
    return _find_one(TICKER=ticker)


def _tickers(**kwargs):
    return [doc['TICKER'] for doc in _find(**kwargs)]


# Return all the tickers that match given refdata criteria

def mandated():
    return _tickers(IS_MANDATED=True)


def new():
    return _tickers(IN_DB=False)


def ohlc():
    return _tickers(BarType='OHLC')


def ohlcv():
    return _tickers(BarType="OHLCV")


def fx_spot():
    return _tickers(SUBTYPE1='FXOUTRIGHT', SUBTYPE2='SPOT')


def etfs():
    return _tickers(Type='EQUITY', SubType1='ETF')


def momentum_tickers():
    return _tickers(TEST_MOM=True)


# Check if given ticker satisfies refdata criteria

def uses_ohlc(ticker):
    return ticker in ohlc()


def uses_pct(ticker):
    return ticker in _tickers(USE_PCT=True)


def uses_net(ticker):
    return ticker in _tickers(USE_PCT=False)


def is_outright(ticker):
    return _tickers(SUBTYPE1='FXOUTRIGHT')


def is_g10(ticker):
    return ticker in _tickers(REGIONS='G10::G10')


def is_ndf(ticker):
    return ticker in _tickers(IS_NDF=True)


def get_base_ticker(ticker) -> BBGTicker:
    return refdata(ticker)['BASE_TICKER']


def is_tested_for_momentum(ticker):
    return ticker in momentum_tickers()


if __name__ == '__main__':
    print(refdata('IHN+1M CURNCY'))
    is_ndf('IHN+1M CURNCY')

