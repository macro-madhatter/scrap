"""Console script for babel."""
import sys
import click
import pathlib

import babel_assets


@click.group()
def cli():
    pass


@cli.command()
def main(args=None):
    """Console script for babel."""
    click.echo("Babel: Reference Data Management Server")
    click.echo(babel_assets.splash())
    return 0


if __name__ == "__main__":
    sys.exit(main())  # pragma: no cover
