"""
Currency related reference data functions + utils
"""
import babel_assets
import pytest
import pandas as pd
from homer.base import Basket, BBGTicker
from typing import Tuple

ORDERED_CCYS = list(babel_assets.CCYVERSE['CCY'].values)

FWD_CODE = {k: v for k, v in
            zip(list(babel_assets.CCYVERSE['CCY'].values),
                list(babel_assets.CCYVERSE['FWD'].values))
            }


def _ccys(cnames=None, filter_vals=None):
    if not cnames and not filter_vals:
        return list(babel_assets.CCYVERSE['CCY'].values)

    if cnames and filter_vals:
        df: pd.DataFrame = babel_assets.CCYVERSE.copy(deep=True)

        for cname, fv in zip(cnames, filter_vals):
            if isinstance(fv, list):
                df = df[df[cname] in fv]
            else:
                df = df[df[cname] == fv]

        return list(df['CCY'].values)


def is_ndf(ccy) -> bool:
    return ccy in _ccys(['IS_NDF'], [True])


def get_ccys(cross: str) -> Tuple[str, str]:
    return cross[:3], cross[3:6]


def ticker_ndf_prefix(ccy) -> str:
    return babel_assets.CCYVERSE[babel_assets.CCYVERSE['CCY'] == ccy].tail(n=1).to_dict('records')[0]['FWD']


def rank(ccy):
    return ORDERED_CCYS.index(ccy)


def cmp(ccy1, ccy2):
    return rank(ccy1) < rank(ccy2)


def to_base(ccy: str, base: str = "USD", as_ticker: bool = True):
    ccypair = base + ccy if cmp(base, ccy) else ccy + base

    if as_ticker:
        return ccypair + " CURNCY"
    else:
        return ccypair


def split_ccypair(ccypair):
    return ccypair[:3], ccypair[3:6]


def ccy_from_ccypair(ccypair, base='USD') -> str:
    ccy1, ccy2 = split_ccypair(ccypair)

    if ccy1 == base:
        return ccy2
    elif ccy2 == base:
        return ccy1
    else:
        err = "Either ccy1: {}, or ccy2: {} should be be base: {}"
        raise ValueError(err.format(ccy1, ccy2, base))


def ccypair_from_ccy(ccy, base='USD', as_ticker: bool = True):
    ccypair = ccy + base if rank(ccy) < rank(base) else base + ccy
    ccypair = ccypair + " CURNCY" if as_ticker else ccypair
    return ccypair


def is_cross(ccypair: str, base: str = "USD"):
    """
    Check if ABCXYZ is a cross
    :param ccypair: str AUDINR CURNCY
    :param base: str USD
    :return: bool True
    """
    ccy1, ccy2 = split_ccypair(ccypair)
    return ccy1 != base and ccy2 != base


def bases_from_cross(cross, base='USD'):
    """
    Split cross ccypair into 2 base ccypairs
    :param base: base ccy to split the cross against
    :param cross: Cross ex. AUDINR CURNCY
    :return: AUDUSD CURNCY, USDINR CURNCY
    """
    cross = cross[:6]  # AUDINR CURNCY --> AUDINR
    ccy1, ccy2 = split_ccypair(cross)

    if ccy1 == ccy2:
        err = "CCY1:{} and CCY2:{} cannot be the same"
        raise ValueError(err.format(ccy1, ccy2))

    if base in [ccy1, ccy2]:
        err = "Base currency: {} already present in cross: {}"
        raise ValueError(err.format(base, cross))

    return to_base(ccy1, base), to_base(ccy2, base)


def base_trades_from_cross(cross, signal, base: str = "USD"):
    ccy1, ccy2 = split_ccypair(cross)
    pair1, pair2 = bases_from_cross(cross, base)

    return {
        pair1: signal if ccy1 == pair1[:3] else -signal,
        pair2: -signal if ccy2 == pair2[:3] else signal
    }


def test_split_cross():
    assert bases_from_cross("AUDINR CURNCY") == \
           ("AUDUSD CURNCY", "USDINR CURNCY")

    assert bases_from_cross("AUDINR CURNCY", "EUR") == \
           ("EURAUD CURNCY", "EURINR CURNCY")

    with pytest.raises(ValueError):
        bases_from_cross("AUDAUD CURNCY", "EUR")

    with pytest.raises(ValueError):
        bases_from_cross("AUDUSD CURNCY")

    assert bases_from_cross("AUDUSD CURNCY", "EUR") == \
           ("EURAUD CURNCY", "EURUSD CURNCY")


def test_split_cross_signal():
    assert base_trades_from_cross("AUDINR CURNCY", -1) == {
        "AUDUSD CURNCY": -1,
        "USDINR CURNCY": -1,
    }

    assert base_trades_from_cross("AUDINR CURNCY", -1, "EUR") == {
        "EURAUD CURNCY": 1,
        "EURINR CURNCY": -1,
    }

    assert base_trades_from_cross("EURCAD CURNCY", 1, "USD") == {
        "EURUSD CURNCY": 1,
        "USDCAD CURNCY": 1,
    }


def test_is_cross():
    assert not is_cross("EURUSD")
    assert is_cross("EURCAD")
    assert not is_cross("EURCAD", base="EUR")


JPY_BASKET: Basket = [
    'USDJPY CURNCY',
    'AUDJPY CURNCY',
    'CADJPY CURNCY',
    'NZDJPY CURNCY',
    'EURJPY CURNCY',
    'CHFJPY CURNCY',
    'SGDJPY CURNCY',
    'CNHJPY CURNCY',
    'JPYKRW CURNCY',
    'GBPJPY CURNCY'
]

EUR_BASKET: Basket = [
    'EURUSD CURNCY',
    'EURAUD CURNCY',
    'EURCAD CURNCY',
    'EURNZD CURNCY',
    'EURJPY CURNCY',
    'EURCHF CURNCY',
    'EURSGD CURNCY',
    'EURCNH CURNCY',
    'EURKRW CURNCY',
    'EURGBP CURNCY'
]

CAD_BASKET: Basket = [
    'USDCAD CURNCY',
    'AUDCAD CURNCY',
    'EURCAD CURNCY',
    'NZDCAD CURNCY',
    'CADJPY CURNCY',
    'CADCHF CURNCY',
    'CADSGD CURNCY',
    'CADCNH CURNCY',
    'CADKRW CURNCY',
    'GBPCAD CURNCY'
]

USD_BASKET: Basket = [
    'USDJPY CURNCY',
    'AUDUSD CURNCY',
    'NZDUSD CURNCY',
    'EURUSD CURNCY',
    'USDCHF CURNCY',
    'USDSGD CURNCY',
    'USDCNH CURNCY',
    'USDKRW CURNCY',
    'USDGBP CURNCY'
]

SGD_BASKET: Basket = [
    'USDSGD CURNCY',
    'AUDSGD CURNCY',
    'EURSGD CURNCY',
    'GBPSGD CURNCY',
    'SGDCNH CURNCY',
    'SGDIDR CURNCY',
    'SGDINR CURNCY',
    'SGDJPY CURNCY',
    'SGDKRW CURNCY',
    'SGDPHP CURNCY',
    'SGDTHB CURNCY',
    'SGDTWD CURNCY'
]
