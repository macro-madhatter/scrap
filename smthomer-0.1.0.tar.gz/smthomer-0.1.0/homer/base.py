from typing import List, Dict, Sequence
from enum import Enum, auto


# noinspection PyMethodParameters
class AutoName(Enum):
    def _generate_next_value_(name, start, count, last_values):
        return name


class PxType(AutoName):
    BID = auto()
    ASK = auto()
    MID = auto()


class Direction(Enum):
    Buy = 1
    Pay = 1
    Sell = -1
    Receive = -1
    Flat = 0


class VolProducts(AutoName):
    CALL = auto()
    PUT = auto()
    STRADDLE = auto()
    STRANGLE = auto()
    FLY = auto()


class BBGField(AutoName):
    PX_OPEN = auto()
    PX_HIGH = auto()
    PX_LOW = auto()
    PX_LAST = auto()
    VOLUME = auto()


BBGTicker = str
BBGTickerList = Sequence[BBGTicker]
Basket = Sequence[BBGTicker]
BBGFieldList = Sequence[BBGField]

Ccy = str

OHLC_FIELDS = [BBGField.PX_LOW,
               BBGField.PX_HIGH,
               BBGField.PX_OPEN,
               BBGField.PX_LAST
               ]

OHLCV_FIELDS = [BBGField.PX_LOW,
                BBGField.PX_HIGH,
                BBGField.PX_OPEN,
                BBGField.PX_LAST,
                BBGField.VOLUME
                ]

FieldMapper: Dict[str, str] = {
    "Date": "date",
    "PX_OPEN": "open",
    "PX_HIGH": "high",
    "PX_LOW": "low",
    "PX_LAST": "close",
    "VOLUME": "volume"
}


# noinspection PyMethodParameters
class AutoNameTenorDelta(Enum):
    def _generate_next_value_(name, start, count, last_values):
        return name[1:] + name[0]


class Delta(AutoNameTenorDelta):
    D5 = auto()
    D10 = auto()
    D15 = auto()
    D25 = auto()
    D50 = auto()


class Tenor(AutoNameTenorDelta):
    W1 = auto()
    M1 = auto()
    M3 = auto()
    M6 = auto()
    M9 = auto()
    M12 = auto()


FX_SWAP_LEGS = [
    (Tenor.W1, Tenor.M1),

    (Tenor.M1, Tenor.M3),
    (Tenor.M1, Tenor.M6),
    (Tenor.M1, Tenor.M9),
    (Tenor.M1, Tenor.M12),

    (Tenor.M3, Tenor.M6),
    (Tenor.M3, Tenor.M9),
    (Tenor.M3, Tenor.M12),

    (Tenor.M6, Tenor.M9),
    (Tenor.M6, Tenor.M12),

    (Tenor.M9, Tenor.M12)
]


def tenors_str() -> Sequence[str]:
    return [t.value for t in Tenor]


class FwdPxType(AutoName):
    POINTS = auto()
    OUTRIGHT = auto()


class Indicator:
    def __init__(self, ticker: BBGTicker, val: float):
        self.ticker = ticker
        self._val = val

    @property
    def val(self):
        return self._val


class Signal:
    def __init__(self, ticker: BBGTicker, direction: int):
        self.ticker = ticker
        self._direction = direction

    @property
    def direction(self):
        return self._direction

    def as_dict(self):
        return {self.ticker: self._direction}

# todo - implement compound types for signal and indicator
