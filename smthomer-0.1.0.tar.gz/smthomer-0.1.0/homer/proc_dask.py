import logging
from typing import Sequence

import numpy as np
import pandas as pd
from pampy import match

import homer.math_utils as mu

import dask.dataframe as dd
from dask.array import from_array

logger = logging.getLogger('Proc')
logger.setLevel(logging.DEBUG)

# create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(formatter)
logger.addHandler(ch)

LB_WINDOWS = (1, 3, 5, 10, 20, 50, 75, 100, 150, 200)

# Assuming transaction/funding/effort costs per day to be 0.025 so 2.5bps charge levied each day
GM_THRESH_PCT: float = 0.025


class Feature:
    pass


class High(Feature):
    pass


class Low(Feature):
    pass


class Mean(Feature):
    pass


def _rolling_measure(df: pd.DataFrame, cname: str, window_size: int, c) -> pd.Series:
    return match(c,
                 High, df[cname].rolling(min_periods=1, window=window_size, center=False).max(),
                 Low, df[cname].rolling(min_periods=1, window=window_size, center=False).min(),
                 Mean, df[cname].rolling(min_periods=1, window=window_size, center=False).mean()
                 )


def _sharpe(pct_returns_arr, thresh_pct=GM_THRESH_PCT):
    return pct_returns_arr.mean() - thresh_pct / pct_returns_arr.std()


def _omega(pct_returns_arr, thresh_pct=GM_THRESH_PCT):
    return mu.omega_ratio(pct_returns_arr, threshold=thresh_pct)


def _sortino(pct_returns_arr, thresh_pct=GM_THRESH_PCT):
    return mu.sortino_ratio(pct_returns_arr, threshold=thresh_pct)


def _updays(pct_returns_arr, thresh_pct=GM_THRESH_PCT):
    return mu.num_gains(pct_returns_arr, threshold=thresh_pct) / len(pct_returns_arr)


def _downdays(pct_returns_arr, thresh_pct=GM_THRESH_PCT):
    return mu.num_losses(pct_returns_arr, threshold=thresh_pct) / len(pct_returns_arr)


def _streak(digi: pd.Series):
    digi = pd.Series(list(digi.values.compute()))
    # noinspection PyTypeChecker
    arr = digi.groupby((digi != digi.shift()).cumsum()).cumcount() + 1
    arr *= digi
    return from_array(arr)


def zscore(x, window):
    r = x.rolling(window=window)
    m = r.mean().shift(1)
    s = r.std(ddof=0).shift(1)
    z = (x - m) / s
    return z


#
# rawbool, default False
#
# Determines if row or column is passed as a Series or ndarray object:
#
# False : passes each row or column as a Series to the function.
#
# True : the passed function will receive ndarray objects instead.
#
# If you are just applying a NumPy reduction function this will achieve much better performance.

def _compute_metrics(df: pd.DataFrame, wsize: int):
    # lookback window PctChg/Hi/Lo/MAvg/UpDown
    df["high_{}D".format(wsize)] = _rolling_measure(df, 'high', wsize, High())
    df["low_{}D".format(wsize)] = _rolling_measure(df, 'low', wsize, Low())

    df["{}DMA".format(wsize)] = _rolling_measure(df, 'close', wsize, Mean())

    # Pct/Net Change and Digital i.e. 1,-1
    df['close_pct_chg_{}d'.format(wsize)] = df['close'].diff(periods=wsize) / df['close'].shift(wsize)
    df['close_pct_chg_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)] * 100
    df['close_net_chg_{}d'.format(wsize)] = df['close'].diff(periods=wsize)
    df['close_digital_{}d'.format(wsize)] = from_array(np.where(df['close_net_chg_{}d'.format(wsize)] > 0, 1, -1))

    # Streak
    df['close_streak_{}d'.format(wsize)] = _streak(df['close_digital_{}d'.format(wsize)])

    # Autocorrelation, lag=1
    if wsize >= 3:
        df['autocorr_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(wsize).apply(
            lambda x: x.autocorr(lag=1), raw=False)

    # Above/Below DMA
    df['diff_from_{}dma'.format(wsize)] = df['close'] - df["{}DMA".format(wsize)]
    df['close_above_{}dma'.format(wsize)] = from_array(np.where(df['diff_from_{}dma'.format(wsize)] > 0, 1, -1))
    df['days_above_{}dma'.format(wsize)] = _streak(df['close_above_{}dma'.format(wsize)])

    # 1-day ZScore using window lookback

    # Price ZScore
    logging.info("Calculating Metrics for Window Size: {}".format(wsize))

    df['close_px_zscore_{}d'.format(wsize)] = zscore(df['close'], window=wsize)

    # Pct ZScore
    df['close_pct_zscore_{}d'.format(wsize)] = zscore(df['close_pct_chg_1d'], window=wsize)

    # Net Change ZScore
    df['close_net_zscore_{}d'.format(wsize)] = zscore(df['close_net_chg_1d'], window=wsize)

    # Performance metrics of underlying itself
    # Sharpe, Sortino, Omega, NumUpDays, NumDownDays

    df['close_sharpe_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(
        min_periods=1,
        window=wsize,
        center=False
    ).apply(_sharpe, raw=True)

    df['close_omega_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(
        min_periods=1,
        window=wsize,
        center=False
    ).apply(_omega, raw=True)

    df['close_sortino_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(
        min_periods=1,
        window=wsize,
        center=False
    ).apply(_sortino, raw=True)

    df['close_num_up_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(
        min_periods=1,
        window=wsize,
        center=False
    ).apply(_updays, raw=True)

    df['close_num_down_{}d'.format(wsize)] = df['close_pct_chg_{}d'.format(wsize)].rolling(
        min_periods=1,
        window=wsize,
        center=False
    ).apply(_downdays, raw=True)

    df['UpDownRatio_{}d'.format(wsize)] = df['close_num_up_{}d'.format(wsize)] / df[
        'close_num_down_{}d'.format(wsize)]

    # Volume Analysis
    if "volume" in df.columns:
        df["volume_high_{}D".format(wsize)] = _rolling_measure(df, 'volume', wsize, High())
        df["volume_low_{}D".format(wsize)] = _rolling_measure(df, 'volume', wsize, Low())

        df["volume_{}DMA".format(wsize)] = _rolling_measure(df, 'volume', wsize, Mean())

        df['volume_pct_chg_{}d'.format(wsize)] = df['volume'].diff(wsize) / df['volume'].shift(wsize)
        df['volume_pct_chg_{}d'.format(wsize)] = df['volume_pct_chg_{}d'.format(wsize)] * 100
        df['volume_net_chg_{}d'.format(wsize)] = df['volume'].diff(periods=wsize)
        df['volume_digital_{}d'.format(wsize)] = from_array(np.where(df['volume_net_chg_{}d'.format(wsize)] > 0, 1, -1))

    return df


def enhance_ohlc(df: pd.DataFrame, windows: Sequence[int] = LB_WINDOWS) -> pd.DataFrame:
    """

    :param df_dask: ohlc/ohlcv dataframe
    :param windows: list of windows to create metrics from

    :return:  ohlc/v dataframe augmented with common timeseries metrics
    """
    df_dask = dd.from_pandas(df, npartitions=1) if isinstance(df, pd.DataFrame) else df

    logging.info("Received windows: {}".format(windows))
    logging.info(df_dask.head())

    # Append 1 so that the simplest metrics are forced to be computed
    if 1 not in windows:
        windows = [1] + list(windows)

    # Open to Close pcnt change:
    df_dask['open_close_pct_chg'] = (df_dask['close'] - df_dask['open']) / df_dask['open']
    df_dask['open_close_pct_chg'] = df_dask['open_close_pct_chg'] * 100

    df_dask = _compute_metrics(df_dask, 1)

    # Run for wsize=1
    for wsize in windows[1:]:
        print(wsize)
        df_dask = _compute_metrics(df_dask, wsize)

    # Since no dependency (yet) on bigger wsizes apart from 1, run in parralel

    return df_dask


if __name__ == '__main__':
    import pathlib

    fname = pathlib.Path.cwd().parent / 'homer_assets' / 'n225.csv'
    df = dd.read_csv(fname)
    df = enhance_ohlc(df, windows=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    print(df.compute().head())
